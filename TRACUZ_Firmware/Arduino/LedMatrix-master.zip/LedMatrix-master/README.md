LedMatrix
==========
LedMatrix is an Arduino Uno library for controlling multiple MAX7219 and MAX7221 Led display drivers in a matrix style layout. It does not support 7-segment displays.

Documentation
-------------
https://github.com/agr00m/LedMatrixSPI/wiki
Also included in the library folder.

Download
--------
https://github.com/agr00m/LedMatrixSPI

Install
-------
The library can be installed using the [standard Arduino library install procedure](http://arduino.cc/en/Guide/Libraries)  







